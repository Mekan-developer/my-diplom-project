<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>TITU LAB</title>

    
    <link href="<?php echo e(URL::to('admin/css/bootstrap.min.css')); ?>" rel="stylesheet">

   
    <link href="<?php echo e(URL::to('admin/css/sb-admin.css')); ?>" rel="stylesheet">

   
    <link href="<?php echo e(URL::to('admin/css/plugins/morris.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(URL::to('admin/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

   <script>
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    "Time " + h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
</script>
</head>

<body onload="startTime()">

    <div id="wrapper">

       
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
           
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#" data-toggle="modal" data-target="#test">OGUZCAMPLAB Admin</a>
            </div>
            
            <ul class="nav navbar-right top-nav">
               
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo e(Auth::user()->f_name); ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                       
                        
                        <li>
                            <a href="<?php echo e(route('settings')); ?>"><i class="fa fa-fw fa-gear"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="<?php echo e(route('logout')); ?>"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
           
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                	<center>
                		<img src="<?php echo e(URL::to('asset/images/admin.png')); ?>" height="80px" width="80px">
                	</center>
                    <li>
                       <a href="#">
                       		<p class="text-center" style="color: #fff"><?php echo e(Auth::user()->l_name); ?>, <?php echo e(Auth::user()->f_name); ?> <?php echo e(Auth::user()->m_name); ?></p>
                       		<p class="text-center" style="color: #fff">Online</p>
                       
                       </a>
                    </li>
                    <li class="active">
                        <a href="<?php echo e(route('staff')); ?>"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
                     <li>
                        <a href="<?php echo e(route('staff_login')); ?>"><i class="fa fa-fw fa-dashboard"></i> LogIn</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('staff_logout')); ?>"><i class="fa fa-fw fa-dashboard"></i> LogOut</a>
                    </li>
                    
                   
                    

                    <li>
                        <a href="<?php echo e(route('staff_report')); ?>"><i class="fa fa-fw fa-dashboard"></i> Reports</a>
                    </li>
                    
                    
                </ul>
            </div>
           
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

               
                <div class="row">
                    <div class="col-lg-12">
                       <h1 id="txt"></h1>
                     
                    </div>
                </div>
               

                <div class="row">
                    <div class="col-lg-8">
                       <div class="panel panel-success">
	                       	<div class="panel-heading">
	                       		
                                <h1>
                                    <?php if(Auth::user()->role->name == 'cas7'): ?>
                                        <strong>Lab B Operation</strong>
                                     <?php elseif(Auth::user()->role->name == 'cas8'): ?>   
                                        <strong>CAS 8 Operation</strong>
                                     <?php else: ?> 
                                     <strong>Lab A Operation</strong> 
                                    <?php endif; ?>

                                </h1>
	                       	</div>
	                       	<div class="panel-body">
	                       		<table class="table">
                                    <thead>
                                        <tr>
                                            <th>PC</th>
                                            <th>Last Name</th>
                                            <th>First Name</th>
                                            <th>Course</th>
                                            
                                            <th>Start</th>
                                            
                                        </tr> 
                                    </thead>  
                                     <tbody>
                                       <?php if($logs->count()): ?>
                                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                             <?php if($log->staff->role_id == $role->role_id): ?>
                                                <td><?php echo e($log->computer_id); ?></td>
                                                <td><?php echo e($log->student->lname); ?></td>
                                                <td><?php echo e($log->student->fname); ?></td>
                                                <td><?php echo e($log->student->course); ?></td>
                                                
                                                <td><?php echo e($log->created_at->diffForHumans()); ?></td>
                                                
                                            <?php endif; ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>  
                                   </tbody>   
                                  
                                </table>
	                       	</div>
                       </div>

                       
                    </div>

                    <div class="col-lg-4">
                    	<div class="panel panel-primary">
                            <div class="panel-heading">
                                <h1>Lab A PC</h1>
                            </div>
                            <div class="panel-body">
                                <table class="table">
                                    <head>
                                        <tr>
                                            <th>No.</th>
                                            <th>Room</th>
                                            <th>Status</th>
                                        </tr>
                                    </head>
                              
                                <tbody>
                                      <?php $__currentLoopData = $pcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($pc->room == 1): ?>
                                        <tr>
                                            <td><a href="#"><?php echo e($pc->pc_no); ?></a></td>
                                            <td>3 floor</td>
                                            <td>
                                                <?php 
                                                    if($pc->status == 0){
                                                        echo 'available';
                                                    }else{
                                                        echo'used';
                                                    }
                                                ?>

                                            </td>
                                            
                                        </tr>
                                        <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </tbody> 
                                   
                                </table>  
                            </div>
                       </div>
                       <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h1>Lab B PC</h1>
                            </div>
                            <div class="panel-body">
                                <table class="table">
                                    <head>
                                        <tr>
                                            <th>No.</th>
                                            <th>Room</th>
                                            <th>Status</th>
                                        </tr>
                                    </head>
                              
                                <tbody>
                                       <?php $__currentLoopData = $pcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($pc->room == 2): ?>
                                        <tr>
                                            <td><a href="#"><?php echo e($pc->pc_no); ?></a></td>
                                            <td>4 floor</td>
                                            <td>
                                                <?php 
                                                    if($pc->status == 0){
                                                        echo 'available';
                                                    }else{
                                                        echo'used';
                                                    }
                                                ?>

                                            </td>
                                            
                                        </tr>
                                        <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </tbody> 
                                   
                                </table>  
                            </div>
                       </div>
                    </div>
                </div>
                
               

               

               
                    
                    

            </div>
           

        </div>
       
        <div class="modal fade" id="test">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-head">
                        
                    </div>
                    <div class="modal-body">
                        
                    </div>
                </div>
            </div>
        </div>

    </div>
   

   
    <script src="<?php echo e(URL::to('admin/js/jquery.js')); ?>"></script>

    
    <script src="<?php echo e(URL::to('admin/js/bootstrap.min.js')); ?>"></script>

    
    <script src="<?php echo e(URL::to('admin/js/plugins/morris/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('admin/js/plugins/morris/morris.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('admin/js/plugins/morris/morris-data.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\diplom Ishim\laravel10\resources\views/staff/main.blade.php ENDPATH**/ ?>