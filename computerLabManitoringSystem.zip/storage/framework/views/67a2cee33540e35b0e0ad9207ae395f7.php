<?php $__env->startSection('title', 'Students'); ?>

<?php $__env->startSection('InternalStyle'); ?>
<style type="text/css">
    .input-group {
        margin-bottom: 10px;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

    <div class="container-fluid">


        <div class="row">
            <div class="col-lg-12">
                <h1>Talyplar</h1>
            </div>
        </div>


        <div class="row">
            <div class="col-lg-12">

                <?php if(Session::has('added')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('added')); ?>

                </div>
                <?php endif; ?>
                <?php if(Session::has('info')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('info')); ?>

                </div>
                <?php endif; ?>
                <div class="panel panel-info">
                    <div class="panel-heading">
                        
                        <button class="btn btn-danger" data-toggle="modal" data-target="#addStudent"><i class="glyphicon glyphicon-retweet"></i> Talyp goşmak</button>
                    </div>
                    <div class="panel-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Ady</th>
                                    <th>Familýasy</th>
                                    


                                    <th>Doglan senesi</th>
                                    <th>Operation</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('student_info', ['student_id'=> $student->barcode])); ?>" class="badge"><?php echo e($student->barcode); ?></a></td>
                                    <td><?php echo e($student->fname); ?></td>
                                    <td><?php echo e($student->lname); ?></td>
                                    
                                    <td><?php echo e($student->dob); ?></td>


                                    <td>
                                        <a href="<?php echo e(route('admin_edit_student', ['student_id'=> $student->barcode])); ?>" class="btn btn-info btn-xs"><i class="glyphicon glyphicon-pencil"></i></a>
                                        <a href="<?php echo e(route('student_delete', ['student_id'=> $student->barcode])); ?>" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <center><?php echo e($students->links()); ?></center>
                    </div>
                </div>


            </div>

            <div class="col-lg-4">

            </div>
        </div>
    </div>


</div>

<div class="modal fade" id="addStudent">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-head">
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <button class="close" data-dismiss="modal" type="button">&copy;</button>
            </div>
            <div class="modal-body">
                <h3>Talybyň maglumaty</h3>
                <form action="<?php echo e(route('studentCheck')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="input-group">
                        <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-qrcode"></i></span>
                        <input type="text" name="barcode" class="form-control" placeholder="talybyň kody" required="">
                    </div>
                    
                    <div class="input-group">
                        <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-camera"></i></span>
                        <input type="file" name="profile" class="form-control" required="">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-user"></i></span>
                        <input type="text" name="fname" class="form-control" placeholder="Ady" required="">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-user"></i></span>
                        <input type="text" name="lname" class="form-control" placeholder="Familýasy" required="">
                    </div>
                    
                    <div class="input-group">
                        <span class="input-group-addon" id="addon1">@</span>
                        <input type="text" name="email" class="form-control" placeholder="Email" required="">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" id="addon1">@</span>
                        <input type="text" name="contact" class="form-control" placeholder="+993" required="">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" id="addon1">Doglan senesi</span>
                        <input type="date" name="dob" class="form-control" placeholder="Date of Birth" required="">
                    </div>
                    <div class="form-group">
                        

                        <label>Kursy</label>
                        <select name="course">
                            <option value="LLD">1-nji kurs</option>
                            <option value="1 course">2-nji kurs</option>
                            <option value="2 course">3-nji kurs</option>
                            <option value="3 course">4-nji kurs</option>
                            <option value="4 course">5-nji kurs</option>
                        </select>
                    </div>



                    <div class="form-group">
                        <textarea class="form-control" placeholder="Salgysy" name="address" required=""></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Ýatda saklat</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diplom Ishim\laravel10\resources\views/admin/student.blade.php ENDPATH**/ ?>