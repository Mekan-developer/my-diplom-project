<?php $__env->startSection('title', 'PCs'); ?>

<?php $__env->startSection('InternalStyle'); ?>
<style type="text/css">
    .input-group {
        margin-bottom: 10px;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper">

    <div class="container-fluid">


        <div class="row" style="margin-bottom: 10px">
            <div class="col-lg-12">
                <h1>Kompýuter</h1>
                <button class="btn btn-danger" data-toggle="modal" data-target="#addPc"><i class="glyphicon glyphicon-retweet"></i> Komýuter goşmak</button>
                <?php if(Session::has('added')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('added')); ?>

                </div>
                <?php endif; ?>
                <?php if(Session::has('info')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session::get('info')); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>


        <div class="row">
            <div class="col-lg-8">

                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h1>3-nji gat laboratoriýa</h1>
                    </div>
                    <div class="panel-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>PC No.</th>
                                    <th>Familýasy</th>
                                    <th>Ady</th>
                                    <th>Kursy</th>
                                    <th>Ýolbaşçy</th>
                                    <th>Başlanan wagty</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($logs->count()): ?>
                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($log->staff->role_id == 2): ?>
                                <tr>
                                    <td><?php echo e($log->computer_id); ?></td>
                                    <td><?php echo e($log->student->fname); ?></td>
                                    <td><?php echo e($log->student->lname); ?></td>
                                    <td><?php echo e($log->student->course); ?></td>

                                    <td><?php echo e($log->staff->l_name); ?></td>
                                    <td><?php echo e($log->created_at->diffForHumans()); ?></td>
                                </tr>

                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>

                        </table>
                    </div>
                </div>

                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h1>4-nji gat laboratoriýa</h1>
                    </div>
                    <div class="panel-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>PC No.</th>
                                    <th>Ady</th>
                                    <th>Familyasy</th>
                                    <th>Kursy</th>
                                    <th>Ýolbaşçy</th>
                                    <th>Başlanan wagyt</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($logs->count()): ?>
                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($log->staff->role_id == 3): ?>
                                <tr>
                                    <td><?php echo e($log->computer_id); ?></td>
                                    <td><?php echo e($log->student->fname); ?></td>
                                    <td><?php echo e($log->student->lname); ?></td>
                                    <td><?php echo e($log->student->course); ?></td>
                                    <td><?php echo e($log->staff->l_name); ?></td>
                                    <td><?php echo e($log->created_at->diffForHumans()); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <h1>Labaratory A PC</h1>
                    </div>
                    <div class="panel-body">
                        <table class="table">
                            <head>
                                <tr>
                                    <th>No.</th>
                                    <th>Labaratory</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </head>

                            <tbody>
                                <?php $__currentLoopData = $pcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($pc->room == 1): ?>
                                <tr>
                                    <td><a href="#"><?php echo e($pc->pc_no); ?></a></td>
                                    <td>LAB A</td>
                                    <td>
                                        <?php 
                                                    if($pc->status == 0){
                                                        echo 'available';
                                                    }else{
                                                        echo'used';
                                                    }
                                                ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin_pc_edit',['pc_id'=> $pc->id, 'room'=> $pc->room])); ?>" class="btn btn-info btn-xs"><i class="glyphicon glyphicon-pencil"></i></a>
                                        <a href="<?php echo e(route('pc_delete', ['pc_id'=> $pc->id, 'room'=> $pc->room])); ?>" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i></a>
                                    </td>

                                </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <h1>Labaratory B PC</h1>
                    </div>
                    <div class="panel-body">
                        <table class="table">
                            <head>
                                <tr>
                                    <th>No.</th>
                                    <th>Labaratory</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </head>

                            <tbody>
                                <?php $__currentLoopData = $pcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($pc->room == 2): ?>
                                <tr>
                                    <td><a href="#"><?php echo e($pc->pc_no); ?></a></td>
                                    <td>LAB B</td>
                                    <td>
                                        <?php 
                                                    if($pc->status == 0){
                                                        echo 'available';
                                                    }else{
                                                        echo'used';
                                                    }
                                                ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin_pc_edit',['pc_id'=> $pc->id, 'room'=> $pc->room])); ?>" class="btn btn-info btn-xs"><i class="glyphicon glyphicon-pencil"></i></a>
                                        <a href="<?php echo e(route('pc_delete', ['pc_id'=> $pc->id, 'room'=> $pc->room])); ?>" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i></a>
                                    </td>

                                </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addPc">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-head">
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            <div class="modal-body">
                <h3>PC Information</h3>
                <form action="<?php echo e(route('addPc')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="input-group">
                        <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                        <input type="text" name="pc" class="form-control" placeholder="PC No." required="">
                    </div>

                    <div class="input-group">
                        <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                        <input type="text" name="pc_ip" class="form-control" placeholder="PC IP." required="">
                    </div>

                    <div class="input-group">
                        <span class="input-group-addon" id="addon1">Laboratory</span>
                        <select name="room" class="form-control" required="">
                            <option value="1"><strong>LAB A (3 floor) </strong></option>
                            <option value="2"><strong>LAB B (4 floor)</strong></option>
                        </select>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                        <input type="text" name="cpu" class="form-control" placeholder="CPU" required="">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                        <input type="text" name="motherboard" class="form-control" placeholder="Motherboard" required="">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                        <input type="text" name="ram" class="form-control" placeholder="RAM" required="">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                        <input type="text" name="hdd" class="form-control" placeholder="HDD" required="">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                        <input type="text" name="keyboard" class="form-control" placeholder="Keyboard" required="">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-blackboard"></i></span>
                        <input type="text" name="mouse" class="form-control" placeholder="Mouse" required="">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diplom Ishim\laravel10\resources\views/admin/pc.blade.php ENDPATH**/ ?>