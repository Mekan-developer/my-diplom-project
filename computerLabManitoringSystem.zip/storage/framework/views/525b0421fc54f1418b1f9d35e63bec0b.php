<?php $__env->startSection('styles'); ?>
<style type="text/css">
	body{
		
		background: url('<?php echo e(URL::to('asset/images/loginlogo.jpg')); ?>') no-repeat center center fixed; 
 		 -webkit-background-size: cover;
 	 -moz-background-size: cover;
 	 -o-background-size: cover;
 	 background-size: cover;

	}
	.input-group{
		margin-bottom: 20px;
	}
	#loginForm{
		margin-top: 10%;
		opacity: 0.9;
		border-radius: 10px;
		opacity: 0.9;
	}
	#loginlogo{
		margin-top: -80px;
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('banner'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-4 col-md-offset-4 well" id="loginForm">
	<center>
		<img src="<?php echo e(URL::to('asset/images/loginlogo.png')); ?>" height="120px" width="120px" id="loginlogo">
		<h3>IÇERI GIRIŞ</h3>
	</center>
		<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>
	<form action="<?php echo e(route('loginVerify')); ?>" method="post">
		<?php echo e(csrf_field()); ?>

		<div class="input-group">
			<span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-user"></i></span>
			<input type="text" name="user_name" class="form-control input-lg" aria-describedby="addon1" placeholder="ulanyjy adyň">
		</div>
		<div class="input-group">
			<span class="input-group-addon" id="addon1"><i class="glyphicon glyphicon-lock"></i></span>
			<input type="password" name="password" class="form-control input-lg" aria-describedby="addon1" placeholder="gizlin koduň">
		</div>
		<button type="submit" class="btn btn-primary btn-block btn-lg">IÇERI GIR</button>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\diplom Ishim\laravel10\resources\views/auth/login.blade.php ENDPATH**/ ?>