<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    
    <link href="<?php echo e(URL::to('admin/css/bootstrap.min.css')); ?>" rel="stylesheet">

   
    <link href="<?php echo e(URL::to('admin/css/sb-admin.css')); ?>" rel="stylesheet">

   
    <link href="<?php echo e(URL::to('admin/css/plugins/morris.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(URL::to('admin/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

    <?php echo $__env->yieldContent('scriptTime'); ?>
    <?php echo $__env->yieldContent('InternalStyle'); ?>

</head>

<body onload="startTime()">

    <div id="wrapper">

       
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
           
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a style="padding-left:80px" class="navbar-brand" href="#" data-toggle="modal" data-target="#test">TITULAB</a>
            </div>
            
            <ul class="nav navbar-right top-nav">
               
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo e(Auth::user()->f_name); ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                       
                        
                        <li>
                            <a href="<?php echo e(route('admin_settings')); ?>"><i class="fa fa-fw fa-gear"></i> Sazlamalar</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="<?php echo e(route('logout')); ?>"><i class="fa fa-fw fa-power-off"></i> Hasapdan çykmak</a>
                        </li>
                    </ul>
                </li>
            </ul>
           
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                	<center>
                		<img src="<?php echo e(URL::to('asset/images/admin.png')); ?>" height="80px" width="80px">
                	</center>
                    <li>
                       <a href="#">
                       		<p class="text-center" style="color: #fff"><?php echo e(Auth::user()->l_name); ?>, <?php echo e(Auth::user()->f_name); ?> <?php echo e(Auth::user()->m_name); ?></p>
                       		<p class="text-center" style="color: #fff">Online</p>
                       
                       </a>
                    </li>
                    <li class="<?php echo e(request()->routeIs('admin')? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin')); ?>"><i class="fa fa-fw fa-dashboard"></i> Panel</a>
                    </li>
                     <li class="<?php echo e(request()->routeIs('admin_staff')? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin_staff')); ?>"><i class="fa fa-fw fa-dashboard"></i> Ýolbaşçylar </a>
                    </li>
                    <li class="<?php echo e(request()->routeIs('admin-student')? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin-student')); ?>"><i class="fa fa-fw fa-dashboard"></i> Talyplar</a>
                    </li>
                   	<li class="<?php echo e(request()->routeIs('admin-pc')? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin-pc')); ?>"><i class="fa fa-fw fa-dashboard"></i> Kompýuterler</a>
                    </li>
                    <li class="<?php echo e(request()->routeIs('monitoring')? 'active' : ''); ?>">
                        <a href="<?php echo e(route('monitoring')); ?>"><i class="fa fa-fw fa-dashboard"></i> Gözegçilik ediş </a>
                    </li>
                    
                    
                </ul>
            </div>
           
        </nav>

        <?php echo $__env->yieldContent('content'); ?>

    </div>
   
    <?php echo $__env->yieldContent('script'); ?>
   
    <script src="<?php echo e(URL::to('admin/js/jquery.js')); ?>"></script>    
    <script src="<?php echo e(URL::to('admin/js/bootstrap.min.js')); ?>"></script>


    
    <script src="<?php echo e(URL::to('admin/js/plugins/morris/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('admin/js/plugins/morris/morris.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('admin/js/plugins/morris/morris-data.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\diplom Ishim\laravel10\resources\views/layouts/admin.blade.php ENDPATH**/ ?>