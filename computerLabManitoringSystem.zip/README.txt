room nom 1 labaratory 3 floor
room nom 2 labaratory 4 floor

role_id 2 manager of 3 floor
role_id 3 manager of 4 floor